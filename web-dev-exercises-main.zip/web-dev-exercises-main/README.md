# web-dev-exercises
HTML/CSS/JavaScript/ReactJS practice exercises

- This is the *[Exercises for  web-dev project](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises)*.


## LICENSE
This repository follows the [MIT License](https://github.com/couchjanu/web-dev-exercises/tree/main/LICENSE).

