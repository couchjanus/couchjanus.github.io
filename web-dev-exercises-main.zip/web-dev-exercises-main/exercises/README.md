# web-dev-exercises
HTML/CSS/JavaScript/ReactJS practice exercises

## Exercises for web-dev project

- This is the *[Exercises for  lecture-01](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises/lecture-01)*.
- This is the *[Exercises for  lecture-02](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises/lecture-02)*.
- This is the *[Exercises for lecture-03](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises/lecture-03)*.
- This is the *[Exercises for lecture-04](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises/lecture-04)*.
- This is the *[Exercises for lecture-05](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises/lecture-05)*.
- This is the *[Exercises for lecture-06](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises/lecture-06)*.
- This is the *[Exercises for lecture-07](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises/lecture-07)*.
- This is the *[Exercises for lecture-08](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises/lecture-08)*.
- This is the *[Exercises for lecture-09](https://github.com/couchjanus/web-dev-exercises/tree/main/exercises/lecture-09)*.

## LICENSE
This repository follows the [MIT License](https://github.com/couchjanus/web-dev-exercises/tree/main/LICENSE).
